D40 使用者已明確核准 v3 design/tasks/validation、技術預設、三個feature PR與private yschiang/orca-delivery。v3 GPT覆核DR-01–DR-10全verified。你現在由設計作者轉為S1 Implementer，開始真正實作。

請先讀 /private/tmp/orca-controller-implementation-20260927/s1-run/assignment.json 及 input-manifest.json，核對本次正式文件hash。唯一可寫產品checkout是 /private/tmp/orca-controller-implementation-20260927/s1-implementer ，branch feat/s1-controller-core，baseline 359ffcf6b439c054e6d5e61e2e80fc2e37944e6b。terminal原cwd是gigaxfer，每次command指定正確cwd；不要寫gigaxfer、原orca-delivery author repo或新cross-node專案。Issue https://github.com/yschiang/orca-delivery/issues/1 已開。

使用 openspec-apply-change，從這個clone查status與instructions apply，讀正式proposal/specs/design/tasks及docs/validation；只實作tasks groups 1–2（S1），不進S2/S3。D40不需再問開工，正常技術細節自行處理；真正改scope/spec/design或例外須先報blocked。凍結candidate與早期handoff待D11字樣是歷史，正式D40為準。

用已釘住的Superpowers 6.3.0 test-driven-development與writing-good-tests，逐行為 Red→Green→Refactor，不批次先把全部production code寫完。每個task先具體化必要測試/介面/AC，再測再寫。原始Red必須在實作前保存：test source commit（可在本feature branch commit red tests）、實際command/cwd/start/end/exit、原始完整stdout/stderr、snapshot SHA/tree、task/AC與hash；寫入assignment的evidence目錄。runner尚未建立時用可讀bootstrap捕捉方式，建立後匯入/引用原件；不可事後replay冒充原始Red，不以collection/import/環境error當行為Red。保持Red commits可取回；不squash/reset抹歷史。

依序完成1.1起的23個S1 tasks；不自行派正式review，不宣告G1/G2/G3/PR Pass。你可正常git commit，根據方法留下每task證據，但先不push或建PR，由我核對G1後處理。每完成一個task寫progress.json（IDs、status、head、已完/未完tasks、evidence refs、blockers、next action）。同時只一個implementation writer，不另開外層loop。45分鐘worker上限，屆時保留checkpoint並回報，絕不為趕完縮scope或虛勾tasks。

CI S1用GitHub Actions required job test，涵蓋Python3.12/uv/pytest、lint/type/build等必要檢查，Linux crash/syscall檢查與macOS sandbox負例要按plan真跑；本地不可做的證據如實標未執行，不能把skipped算成功。N-V3-01採正式design尾段：G1 deterministic，method_changed語意由新契約G2，補測避免deadlock。

所有行為完成或真正blocked時，先保存inbox/result.json，含run/task/attempt IDs、execution_status、actual head/base、summary、task statuses、tests/evidence refs、findings或pending questions、model/native session觀察。result succeeded不等gate passed。最終全量相關回歸要指向實際head。不要自改AC、不可降低檢查、不可把未完成說完成。現在開始S1。
