#!/usr/bin/env python3
"""Bootstrap evidence capture used before task 1.2's runner exists (and to wrap it afterwards).

Usage: bootstrap_capture.py <task_id> <kind> <ac_ids,comma> <cwd> -- <argv...>
Writes <evidence>/<task_id>/<kind>-<n>.json plus raw stdout/stderr files. Never edits the repo.
"""
import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path

EVID = Path(__file__).resolve().parent


def git(cwd, *a):
    return subprocess.run(["git", *a], cwd=cwd, capture_output=True, text=True).stdout.strip()


def main():
    sep = sys.argv.index("--")
    task, kind, acs, cwd = sys.argv[1:sep]
    argv = sys.argv[sep + 1:]
    out = EVID / task
    out.mkdir(parents=True, exist_ok=True)
    n = len(list(out.glob(f"{kind}-*.json"))) + 1
    snap = {"head": git(cwd, "rev-parse", "HEAD"), "tree": git(cwd, "rev-parse", "HEAD^{tree}"),
            "status_porcelain": git(cwd, "status", "--porcelain", "-uall")}
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(argv, cwd=cwd, capture_output=True)
    end = datetime.datetime.now(datetime.timezone.utc).isoformat()
    files = {}
    for name, data in (("stdout", p.stdout), ("stderr", p.stderr)):
        f = out / f"{kind}-{n}.{name}.txt"
        f.write_bytes(data)
        files[name] = {"path": str(f), "sha256": hashlib.sha256(data).hexdigest()}
    rec = {"schema_version": 1, "producer": {"tool": "bootstrap_capture.py",
           "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
           "run_id": "bootstrap-s1-20260927", "attempt_id": "s1-impl-01", "task_id": task, "kind": kind,
           "ac_ids": [a for a in acs.split(",") if a], "cwd": cwd, "argv": argv,
           "started_at": start, "ended_at": end, "exit_code": p.returncode,
           "snapshot": snap, "output": files, "coordinated_by": "collaborator"}
    body = json.dumps(rec, ensure_ascii=False, indent=2)
    (out / f"{kind}-{n}.json").write_text(body)
    print(f"{out}/{kind}-{n}.json exit={p.returncode} head={snap['head'][:12]} dirty={bool(snap['status_porcelain'])}")
    sys.stdout.write(p.stdout.decode(errors="replace")[-3000:])


if __name__ == "__main__":
    main()
