#!/usr/bin/env python3
"""Update inbox/progress.json: progress.py <done_task_id|-> <next_action> [blocker...]"""
import datetime, json, os, subprocess, sys
from pathlib import Path
RUN = Path(__file__).resolve().parents[1]; REPO = "/private/tmp/orca-controller-implementation-20260927/s1-implementer"
ALL = [f"1.{i}" for i in range(1, 10)] + [f"2.{i}" for i in range(1, 15)]
p = RUN / "inbox" / "progress.json"
d = json.loads(p.read_text()) if p.exists() else {"schema_version": 1, "run_id": "bootstrap-s1-20260927",
     "task_id": "S1-core", "attempt_id": "s1-impl-01", "base_sha": "359ffcf6b439c054e6d5e61e2e80fc2e37944e6b", "tasks": {}}
if sys.argv[1] != "-":
    ev = sorted(str(x) for x in (RUN / "evidence" / sys.argv[1]).glob("*.json"))
    d["tasks"][sys.argv[1]] = {"status": os.environ.get("STATUS", "completed"), "note": os.environ.get("NOTE", ""), "evidence": ev}
d["head"] = subprocess.run(["git", "rev-parse", "HEAD"], cwd=REPO, capture_output=True, text=True).stdout.strip()
d["completed"] = [t for t in ALL if d["tasks"].get(t, {}).get("status") == "completed"]
d["remaining"] = [t for t in ALL if t not in d["completed"]]
d["next_action"] = sys.argv[2]; d["blockers"] = sys.argv[3:]
d["updated_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
p.write_text(json.dumps(d, ensure_ascii=False, indent=2)); print(p, d["completed"], d["head"][:12])
