#!/usr/bin/env python3
"""Write inbox/checkpoint-N.json (mode=checkpoint) or the single final inbox/result.json (mode=final)."""
import collections, datetime, glob, json, subprocess, sys
RUN = "/private/tmp/orca-controller-implementation-20260927/s1-run"
R = "/private/tmp/orca-controller-implementation-20260927/s1-implementer"
g = lambda *a: subprocess.run(["git", *a], cwd=R, capture_output=True, text=True).stdout.strip()
mode = sys.argv[1]
prog = json.load(open(f"{RUN}/inbox/progress.json"))
T = "/Users/johnson.chiang/.claude/projects/-Users-johnson-chiang-workspace-gigaxfer/6cddf430-fc81-402c-b21d-be31c3f95a33.jsonl"
models, last = collections.Counter(), None
for line in open(T):
    try: o = json.loads(line)
    except Exception: continue
    if o.get("type") == "assistant":
        m = o.get("message", {}); models[m.get("model")] += 1; last = {"message_id": m.get("id"), "request_id": o.get("requestId"), "timestamp": o.get("timestamp")}
ALL = [f"1.{i}" for i in range(1, 10)] + [f"2.{i}" for i in range(1, 15)]
now = datetime.datetime.now().astimezone()
start = datetime.datetime.fromisoformat("2026-09-27T12:36:40+08:00")
checked = [l.split()[2] for l in open(f"{R}/openspec/changes/implement-delivery-loop/tasks.md") if l.startswith("- [x]")]
res = {
 "schema_version": 1, "run_id": "bootstrap-s1-20260927", "task_id": "S1-core", "attempt_id": "s1-impl-01",
 "role": "implementer", "coordinated_by": "collaborator", "kind": "final_result" if mode == "final" else "checkpoint",
 "execution_status": "blocked",
 "reason": "checkpoint_incomplete" if mode == "final" else "checkpoint",
 "blocked_reason": ("checkpoint_incomplete: attempt stopped by the coordinator before the 45-minute cap; S1 incomplete "
                    "(task 2.10 step loop, 1.3 Linux CI check, 2.14 gates); continued in a new isolated attempt"
                    if mode == "final"
                    else "checkpoint while running (not a timeout)"),
 "note": "execution_status is not a gate result: G1/G2/G3 not evaluated, no PR, no push, no Pass claimed",
 "corrections": ["No worker_time_limit is claimed: the attempt ended at the coordinator's instruction before the cap.", "An earlier inbox/result.json written at 13:06:58 (~30m18s elapsed) wrongly claimed a timeout; it was renamed to inbox/checkpoint-1.json (coordinator archived it as an unaccepted checkpoint observation). This is the only final result."],
 "elapsed": {"started_at": start.isoformat(), "written_at": now.isoformat(timespec="seconds"),
             "elapsed_seconds": int((now - start).total_seconds()), "deadline": "2026-09-27T13:21:40+08:00"},
 "actual": {"cwd": R, "branch": g("rev-parse", "--abbrev-ref", "HEAD"), "head": g("rev-parse", "HEAD"),
            "base": "359ffcf6b439c054e6d5e61e2e80fc2e37944e6b", "commits_since_base": int(g("rev-list", "--count", "359ffcf..HEAD")),
            "worktree_clean": g("status", "--porcelain") == "", "pushed": False, "pr": None},
 "task_statuses": {t: prog["tasks"].get(t, {}).get("status", "not_started") for t in ALL},
 "tasks_md_checked": checked,
 "task_notes": {t: v.get("note") for t, v in prog["tasks"].items() if v.get("note")},
 "remaining": {
   "1.3": "implemented; Linux strace syscall-ordering test written but not executed (runs in CI linux job, not pushed); checkbox unchecked",
   "2.10": "done: intake routing, dispatch authorization, D27 deps, draft/impact guards, reassess and the three gate e2e paths (pre-PR→PR→Pass, base-only recheck/conflict, contract change). NOT done: the controller step() loop that drives fake runtime/GitHub through outbox dispatch, inbox result import and integrate end to end; checkbox unchecked",
   "2.14": "not started: requires push, CI 'test' result, independent review (coordinator-owned G1/G2/G3)"},
 "tests": {"final_regression": {"evidence": "evidence/S1/regression-2.json", "junit": "evidence/S1/regression-2-junit.xml",
                                "result": "179 passed, 1 skipped (Linux-only strace ordering: NOT executed, not counted as pass)",
                                "head_at_run": "8a291a194b24"},
           "lint": "evidence/S1/lint-2.json", "typecheck": "evidence/S1/typecheck-2.json", "build": "evidence/S1/build-2.json",
           "os_layer": "evidence/1.9/green-2.json (real macOS Seatbelt, design 10.4 probes incl. keychain/gh auth token with synthetic credentials and unsandboxed control runs)",
           "ci": "not run (no push). Workflow: jobs linux + macos upload JUnit artifacts; required check 'test' needs both and fails on failure/cancel/skip",
           "not_claimed": ["R", "GH", "E2E", "CI", "Linux sandbox launcher", "Linux strace ordering", "power-loss durability"]},
 "evidence_index": {t: sorted(p.replace(RUN + "/", "") for p in glob.glob(f"{RUN}/evidence/{t}/*.json")) for t in sorted(set(prog["tasks"]) | {"S1"})},
 "red_before_green": "Each behavior task has red-N.json captured on a committed red-test commit (interface stubs raise NotImplementedError, so Red is an assertion/call failure, never collection/import) before the implementing commit; all captures by bootstrap_capture.py (sha256 inside each record). The 1.2 runner exists but S1 bootstrap evidence was not re-routed through it.",
 "test_changes_after_red": [
   "1.2: test helper used plain git status, refreshing the worker index; switched to --no-optional-locks (assertion unchanged)",
   "1.6: abandon-validation test lacked rA state dir; setup fixed so the 'refused' path is exercised (assertion unchanged)",
   "1.7: session_created crash cell redesigned as a disk fixture plus an in-send crash case; new red commit and red-2 capture before green",
   "1.9: probes pin /usr/bin/git (x86 /usr/local/bin/git cannot exec under Seatbelt); push denial judged by effect; credential probes use control runs",
   "2.9: unused-variable rename only (lint)",
   "2.11: exposed a production bug fixed at the root: version keys now use 'vk:' so the store barrier no longer treats them as blob refs"],
 "findings": [
   {"id": "S1-N1", "kind": "spec_wording_ambiguity", "detail": "design §5.3 matrix cell skills×G3 says R-unaffected, while R-reobserve and task 2.1 (DR-10) require G3 re-query after any key change. Per coordinator: implemented G3=R-reobserve for every field; spec/design unchanged; for the independent Reviewer."},
   {"id": "S1-N2", "kind": "environment", "detail": "/usr/local/bin/git on this host is x86_64 and cannot exec under Seatbelt (Bad CPU type); S2 runtime preflight must verify required binaries exec inside the sandbox."},
   {"id": "S1-N3", "kind": "design_detail", "detail": "Some tools hide EPERM (git push); keychain reads happen in securityd so file-read deny is insufficient. Probe suite accepts effect-verified and control-verified denials; the boundary denies keychain mach services."}],
 "pending_questions": [],
 "model_observation": {"requested_model": "claude-opus-5-5", "transcript_models": dict(models), "last_assistant_record": last,
                       "anthropic_base_url": "local proxy http://127.0.0.1:8787/w/claude (upstream model not independently attested)",
                       "runtime": "Claude Code 2.1.283 (Orca terminal per assignment)", "native_session": "6cddf430-fc81-402c-b21d-be31c3f95a33"},
}
out = f"{RUN}/inbox/result.json" if mode == "final" else f"{RUN}/inbox/checkpoint-{sys.argv[2]}.json"
json.dump(res, open(out, "w"), ensure_ascii=False, indent=2)
print(out, res["elapsed"], res["actual"]["head"][:12], res["tasks_md_checked"])
