#!/usr/bin/env python3
"""s1-impl-03 progress: progress.py <gap|-> <status> <next_action> [note]"""
import datetime, json, subprocess, sys
from pathlib import Path
D = Path(__file__).resolve().parents[1]; REPO = "/private/tmp/orca-controller-implementation-20260927/s1-implementer-03"
p = D / "inbox" / "progress.json"
d = json.loads(p.read_text())
if sys.argv[1] != "-":
    d["gaps"][sys.argv[1]]["status"] = sys.argv[2]
    d["gaps"][sys.argv[1]]["evidence"] = sorted(str(x) for x in (D / "evidence" / sys.argv[1]).glob("*.json"))
    if len(sys.argv) > 4: d["gaps"][sys.argv[1]]["note"] = sys.argv[4]
d["head"] = subprocess.run(["git", "rev-parse", "HEAD"], cwd=REPO, capture_output=True, text=True).stdout.strip()
d["next_action"] = sys.argv[3]
d["updated_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
p.write_text(json.dumps(d, ensure_ascii=False, indent=2)); print({k: v["status"] for k, v in d["gaps"].items()}, d["head"][:12])
