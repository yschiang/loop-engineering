請讀本目錄 assignment.json、前 result、正式 spec/design/tasks/validation，繼續已核准 S1（不是新 scope）。Opus attempt02 已停止。只寫新 clone /private/tmp/orca-controller-implementation-20260927/s1-implementer-03 及本 attempt inbox/evidence；舊 clone/result/evidence 不可改。累計 active 3044秒、修正輪次0。本次45min最大值、無需等deadline。

協作者不接受 task2.10 已完成的判定：你明列 G1 fixable gap 缺自動退回，仍屬原design §3要求。請完整檢查所有 S1 tasks 是否只是helper完成卻未接主流程，補足原核准規格，不要再將核心行為以「S2 adapter」名義略過。S2 real runtime/GitHub 及 S3 skill/E2E 不在範圍。下列是協作者讀取結果後確認要核對的接線缺口，非正式獨立G2 review：

1. G1 可修缺失退回原 producing work unit（不另增 review correction round）；不可得歷史Red/不可重現照原政策Blocked。應有真component整合驗證。
2. 主流程須實際執行 authority、ticket/current plan binding、D27依賴、budget累計/期限/infra重試、skill pinning、sandbox派工guard。現在 loop.py 只用 may_dispatch_implementation(approval)；已有controller.authorize_dispatch/dependency_ready/budget helpers不等於實際派工有保護。不得只在測試手設passed布林值。
3. 外部 version re-read需涵蓋head/base/merge-base與bindings；Pass前只pr_head不夠。ready_for_acceptance重讀改變亦須失效。把已有resume/version helper正確串入真入口。測 head unchanged/base changed、contract changed 走完整loop，不只手動reassess helper。
4. Outbox persist-before-effects涵蓋整合/push/PR/發布；_step_implement直接integrate後才store.commit需驗 crash及恢復。原design step純轉移與副作用outbox責任需保留，不能用純函式名義包直接副作用。
5. start/adopt 不可重置既存run/budget；adopt需真正匯入任務/版本與handoff條件，不可空tasks加任意phase。已知decision kinds不可接受卻no-op；revise/adopt_binding/unblock/resolve/waive/abandon等要履行已核准契約或明確拒絕缺資料，不能回成功。人工accept→retro outbox、return→有實際fix工作，不只改phase。
6. Evidence原始stdout/stderr與replay結果需durable，不能只存record digest後刪raw；CLI evidence不得覆寫已存在同名歷史證據。N/A獨立eligibility的S1 core路徑仍要存在。
7. 讀 formal S1 AC/task 做剩餘缺口自檢，task真正完成才勾；不可明列漏功能同時execution succeeded/tasks completed。若限時內做不完誠實checkpoint並列清楚，不能把規格縮成通過現有tests。

全部仍用 openspec-apply-change + Superpowers TDD；每組行為先Red存證再實作，修根因，保留原證據。請在初始progress列出核對後真正待完成項，再逐項完成。保持scope，遇到真正矛盾寫具體來源/影響。所有writer停後一次寫final，附精確head與本地regression/lint/mypy/build證據。不push/建PR/正式review；CI/G2由協作者接手。GitHub private repo目前required-check API403是協作者處理的bootstrap政策問題，不得因此改產品fail-closed規則。
