#!/usr/bin/env python3
"""s1-impl-02 progress: progress.py <item|-> <status> <next_action> [note]"""
import datetime, json, subprocess, sys
from pathlib import Path
D = Path(__file__).resolve().parents[1]; REPO = "/private/tmp/orca-controller-implementation-20260927/s1-implementer-02"
p = D / "inbox" / "progress.json"
d = json.loads(p.read_text()) if p.exists() else {
    "schema_version": 1, "run_id": "bootstrap-s1-20260927", "task_id": "S1-core-continuation",
    "attempt_id": "s1-impl-02", "base_sha": "8a291a194b24225881cce33c5d6e5b9c3f8baa59",
    "started_at_utc": "2026-09-27T05:20:44Z", "deadline_utc": "2026-09-27T06:05:44Z",
    "carried_active_seconds": 2334, "correction_rounds_used": 0, "items": {}}
if sys.argv[1] != "-":
    ev = sorted(str(x) for x in (D / "evidence" / sys.argv[1]).glob("*.json"))
    d["items"][sys.argv[1]] = {"status": sys.argv[2], "note": sys.argv[4] if len(sys.argv) > 4 else "", "evidence": ev}
d["head"] = subprocess.run(["git", "rev-parse", "HEAD"], cwd=REPO, capture_output=True, text=True).stdout.strip()
d["next_action"] = sys.argv[3]
d["updated_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
p.write_text(json.dumps(d, ensure_ascii=False, indent=2)); print(p, {k: v["status"] for k, v in d["items"].items()}, d["head"][:12])
