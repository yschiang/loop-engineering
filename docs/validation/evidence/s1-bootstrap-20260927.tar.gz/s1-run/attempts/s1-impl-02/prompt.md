請完整讀本目錄 assignment.json 與前 attempt 的 final result。新 attempt=s1-impl-02，唯一產品寫入位置 /private/tmp/orca-controller-implementation-20260927/s1-implementer-02，branch feat/s1-controller-core-02。原attempt已停止，請勿再寫原clone、原inbox/result或原evidence；沿用其commit歷史及已存證據，所有新進度/證據/result写本目錄的inbox/evidence。新bootstrap_capture.py已將attempt_id改為02；呼叫時傳入新cwd。不要沿用舊progress.py的硬編碼repo/output。

本次只完成S1原計畫尚缺的整合，不進S2/S3：
1. 完成task2.10真正的step/reconcile主流程，把persisted state、outbox dispatch、fake runtime/GitHub、result import、integration、gates/correction接起來。必須有跨元件可觀察驗證，不能只有手工拼好passed布林值的helper測試。依D40原design實作，必要欄位來自assignment/results/evidence，缺少不能默認通過。
2. 落實design §1所列CLI接線（init/start/adopt/status/resume/decide/reconcile/preflight/evidence run/submit-result）：命令要能調用已實作核心並留下真實狀態/結果，不可只列help或無條件return0。S1未有real runtime/GitHub adapter時，清楚回報未配置/unsupported，不假裝外部完成；用fake adapters驗完整core loop是S1授權範圍。旗標細節可在已核准design內自行決定並記錄用法。
3. 更新tasks/validation，完成S1本地整合與當前head回歸；2.14的真CI/獨立review仍由協作者執行，不自行勾未完成的gate。保留S2/R/GH/E2E未覆蓋。

每個新行為維持Superpowers TDD，先保存有效Red再實作，原始輸出/exit/commit/task/AC/hash；不得覆寫旧證據。所有新behavior也需新增對应測試。維持範圍內完整解法，遇到設計/AC衝突先保存具體影響。

45分鐘是最大執行時間：開始時記真實UTC與deadline，完成就立刻交付；不要等待到deadline，也不要留sleep背景shell。進行中只寫progress/checkpoint。完成或真到限後，在你已停止全部writer時，原子提交一次final result.json（IDs+head/base+tasks+evidence+限制+native model/session），然後結束本attempt。若有工作未完成，明列partial/blocked原因，不宣稱Pass。四小時總預算沿用、修正輪次0不重置。不要push/建PR/派正式review，協作者核對G1再處理。
